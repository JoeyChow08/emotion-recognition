# !bin/bash
# train from begin
python train.py --dataset="iemocap" --modalities="atv"
